import fetch from 'node-fetch';

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) throw `[ *TIKTOK* ]\n\nCara penggunaan nya ${usedPrefix}${command} <link tiktok>\n\n_Tanpa tanda kurung_`

  let res2 = await fetch(`http://localhost/api/tiktok?url=${args[0]}`)
  if (res2.status !== 200) throw await res2.text();

  // Membaca Json File
  let json2 = await res2.json();
  if (!json2.status) throw json2;

  // Mengambil info data video yang ingin dikirimkan
  let videoInfo = 
    `Views: ${json2.result.data.play_count}
Like: ${json2.result.data.digg_count}
Comment: ${json2.result.data.comment_count}\n
Username: tiktok.com/@${json2.result.data.author.unique_id}`;
  m.reply(videoInfo.trim());
  
  // Menambahkan delay 3 detik
  setTimeout(async () => {
    // Mengirim Video Convert setelah delay
    let url = json2.result.data.play;
    if (!url) throw 'Gagal mengambil url download';
    let txt = `${json2.result.data.title}`;

    await conn.sendFile(m.chat, url, 'tiktok.mp4', txt.trim(), m);
  }, 1); // 3000 milidetik = 3 detik
};

handler.help = ['tiktok'].map(v => v + ' <url>');
handler.tags = ['downloader'];
handler.command = /^(tt|tiktok|ttdl)$/i;
handler.limit = true;

export default handler;
