import { readdirSync } from 'fs'
import { join } from 'path'

let handler = async (m, { conn }) => {
    try {
        const tmpFolder = '../tmp' // Ubah sesuai dengan lokasi folder tmp Anda
        const files = readdirSync(tmpFolder)

        if (files.length === 0) {
            return conn.reply(m.chat, 'Tidak ada file di folder tmp.', m)
        }

        for (const file of files) {
            const filePath = join(tmpFolder, file)
            await conn.sendFile(m.chat, filePath, file, 'Berikut adalah file dari folder tmp:', m)
        }
    } catch (err) {
        console.error(err)
        conn.reply(m.chat, 'Terjadi kesalahan saat mengirim file.', m)
    }
}

handler.command = /^(files)$/i
handler.tags = ['admin']

export default handler
