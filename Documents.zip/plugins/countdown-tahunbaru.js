import { areJidsSameUser } from '@whiskeysockets/baileys'
let handler = async (m, { conn, participants }) => {
    const ultah59 = new Date('December 31 2022 17:59:59')
    const sekarat59 = new Date().getTime() 
    const Kurang59 = ultah59 - sekarat59
    const ohari59 = Math.floor( Kurang59 / (1000 * 60 * 60 * 24));
    const ojam59 = Math.floor( Kurang59 % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
    const onet59 = Math.floor( Kurang59 % (1000 * 60 * 60) / (1000 * 60))
    const detek59 = Math.floor( Kurang59 % (1000 * 60) / 1000)
// BANG
const ultah58 = new Date('December 31 2022 17:59:58')
const sekarat58 = new Date().getTime() 
const Kurang58 = ultah58 - sekarat58
const ohari58 = Math.floor( Kurang58 / (1000 * 60 * 60 * 24));
const ojam58 = Math.floor( Kurang58 % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
const onet58 = Math.floor( Kurang58 % (1000 * 60 * 60) / (1000 * 60))
const detek58 = Math.floor( Kurang58 % (1000 * 60) / 1000)
// BANG
const ultah57 = new Date('December 31 2022 17:59:57')
const sekarat57 = new Date().getTime() 
const Kurang57 = ultah57 - sekarat57
const ohari57 = Math.floor( Kurang57 / (1000 * 60 * 60 * 24));
const ojam57 = Math.floor( Kurang57 % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
const onet57 = Math.floor( Kurang57 % (1000 * 60 * 60) / (1000 * 60))
const detek57 = Math.floor( Kurang57 % (1000 * 60) / 1000)
// BANG
const ultah56 = new Date('December 31 2022 17:59:56')
const sekarat56 = new Date().getTime() 
const Kurang56 = ultah56 - sekarat56
const ohari56 = Math.floor( Kurang56 / (1000 * 60 * 60 * 24));
const ojam56 = Math.floor( Kurang56 % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
const onet56 = Math.floor( Kurang56 % (1000 * 60 * 60) / (1000 * 60))
const detek56 = Math.floor( Kurang56 % (1000 * 60) / 1000)
// BANG
const ultah55 = new Date('December 31 2022 17:59:55')
const sekarat55 = new Date().getTime() 
const Kurang55 = ultah55 - sekarat55
const ohari55 = Math.floor( Kurang55 / (1000 * 60 * 60 * 24));
const ojam55 = Math.floor( Kurang55 % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
const onet55 = Math.floor( Kurang55 % (1000 * 60 * 60) / (1000 * 60))
const detek55 = Math.floor( Kurang55 % (1000 * 60) / 1000)
// BANG
const ultah54 = new Date('December 31 2022 17:59:54')
const sekarat54 = new Date().getTime() 
const Kurang54 = ultah54 - sekarat54
const ohari54 = Math.floor( Kurang54 / (1000 * 60 * 60 * 24));
const ojam54 = Math.floor( Kurang54 % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
const onet54 = Math.floor( Kurang54 % (1000 * 60 * 60) / (1000 * 60))
const detek54= Math.floor( Kurang54 % (1000 * 60) / 1000)
// BANG
const ultah53 = new Date('December 31 2022 17:59:53')
const sekarat53 = new Date().getTime() 
const Kurang53 = ultah53 - sekarat53
const ohari53 = Math.floor( Kurang53 / (1000 * 60 * 60 * 24));
const ojam53 = Math.floor( Kurang53 % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
const onet53 = Math.floor( Kurang53 % (1000 * 60 * 60) / (1000 * 60))
const detek53 = Math.floor( Kurang53 % (1000 * 60) / 1000)
// BANG
const ultah52 = new Date('December 31 2022 17:59:52')
const sekarat52 = new Date().getTime() 
const Kurang52 = ultah52 - sekarat52
const ohari52 = Math.floor( Kurang52 / (1000 * 60 * 60 * 24));
const ojam52 = Math.floor( Kurang52 % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
const onet52 = Math.floor( Kurang52 % (1000 * 60 * 60) / (1000 * 60))
const detek52 = Math.floor( Kurang52 % (1000 * 60) / 1000)
// BANG
const ultah51 = new Date('December 31 2022 17:59:51')
const sekarat51 = new Date().getTime() 
const Kurang51 = ultah51 - sekarat51
const ohari51 = Math.floor( Kurang51 / (1000 * 60 * 60 * 24));
const ojam51 = Math.floor( Kurang51 % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
const onet51 = Math.floor( Kurang51 % (1000 * 60 * 60) / (1000 * 60))
const detek51 = Math.floor( Kurang51 % (1000 * 60) / 1000)
// BANG
const ultah50 = new Date('December 31 2022 17:59:50')
const sekarat50 = new Date().getTime() 
const Kurang50 = ultah50 - sekarat50
const ohari50 = Math.floor( Kurang50 / (1000 * 60 * 60 * 24));
const ojam50 = Math.floor( Kurang50 % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
const onet50 = Math.floor( Kurang50 % (1000 * 60 * 60) / (1000 * 60))
const detek50 = Math.floor( Kurang50 % (1000 * 60) / 1000)
// BANG
const ultah49 = new Date('December 31 2022 17:59:49')
const sekarat49 = new Date().getTime() 
const Kurang49 = ultah49 - sekarat49
const ohari49 = Math.floor( Kurang49 / (1000 * 60 * 60 * 24));
const ojam49 = Math.floor( Kurang49 % (1000 * 60 * 60 * 24) / (1000 * 60 * 60))
const onet49 = Math.floor( Kurang49 % (1000 * 60 * 60) / (1000 * 60))
const detek49 = Math.floor( Kurang49 % (1000 * 60) / 1000)

    let users = m.mentionedJid.filter(u => !areJidsSameUser(u, conn.user.id))
    let promoteUser = []
    for (let user of users)
        if (user.endsWith('@s.whatsapp.net') && !(participants.find(v => areJidsSameUser(v.id, user)) || { admin: true }).admin) {
            const res = await conn.groupParticipantsUpdate(m.chat, [user], 'promote')
            await delay(1 * 3000)
        }
    m.reply(`Selamat Tahun baru  : ${ohari59} Hari ${ojam59} Jam ${onet59} Menit ${detek59} Detik Lagi`)
    await delay(1 * 3000)
    m.reply(`Selamat Tahun baru  : ${ohari58} Hari ${ojam58} Jam ${onet58} Menit ${detek58} Detik Lagi`)
    await delay(1 * 3000)
    m.reply(`Selamat Tahun baru  : ${ohari57} Hari ${ojam57} Jam ${onet57} Menit ${detek57} Detik Lagi`)
    await delay(1 * 3000)
    m.reply(`Selamat Tahun baru  : ${ohari56} Hari ${ojam56} Jam ${onet56} Menit ${detek56} Detik Lagi`)
    await delay(1 * 3000)
    m.reply(`Selamat Tahun baru  : ${ohari55} Hari ${ojam55} Jam ${onet55} Menit ${detek55} Detik Lagi`)
    await delay(1 * 3000)
    m.reply(`Selamat Tahun baru  : ${ohari54} Hari ${ojam54} Jam ${onet54} Menit ${detek54} Detik Lagi`)
    await delay(1 * 3000)
    m.reply(`Selamat Tahun baru  : ${ohari53} Hari ${ojam53} Jam ${onet53} Menit ${detek53} Detik Lagi`)
    await delay(1 * 3000)
    m.reply(`Selamat Tahun baru  : ${ohari52} Hari ${ojam52} Jam ${onet52} Menit ${detek52} Detik Lagi`)
    await delay(1 * 3000)
    m.reply(`Selamat Tahun baru  : ${ohari51} Hari ${ojam51} Jam ${onet51} Menit ${detek51} Detik Lagi`)
    await delay(1 * 3000)
    m.reply(`Selamat Tahun baru  : ${ohari50} Hari ${ojam50} Jam ${onet50} Menit ${detek50} Detik Lagi`)
    await delay(1 * 3000)

}
handler.tags = ['owner']
handler.command = /^(tes)$/i

handler.owner = true

export default handler

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))