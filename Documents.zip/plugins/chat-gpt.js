import { Configuration, OpenAIApi } from "openai";
let handler = async (m, { conn, text }) => {
  if (!text) throw "[!] Masukkan teks."
  // const configuration = new Configuration({
  //   apiKey: "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"
  // });
  // const openai = new OpenAIApi(configuration);
  // const response = await openai.createChatCompletion({
  //   model: "gpt-3.5-turbo",
  //   messages: [
  //     { role: "system", content: "Aku Adalah KiBOT, Yang Di Kembangkan Oleh Kiro" },
  //     { role: "user", content: text }
  //   ]
  // });
  m.reply(`Tentu, aku bisa membantumu membuat teks prosedur pembuatan roti sandwich. Berikut ini contoh teks prosedur pembuatan roti sandwich:

  ---
  
  **Judul: Cara Membuat Roti Sandwich**
  
  **Bahan-bahan:**
  1. Roti (pilih sesuai selera, bisa roti tawar atau roti gandum)
  2. Isi (daging, keju, sayuran, saus, dll.)
  3. Mentega atau margarin
  
  **Alat:**
  1. Pisau dapur
  2. Talenan
  3. Sendok atau spatula
  
  **Langkah-langkah:**
  
  1. **Persiapan Bahan:**
     - Siapkan roti sesuai selera, baik roti tawar maupun roti gandum.
     - Pilih isi sesuai selera, seperti daging, keju, dan sayuran segar.
     - Siapkan mentega atau margarin untuk dioleskan pada roti.
  
  2. **Potong Sayuran dan Bahan Lainnya:**
     - Jika menggunakan sayuran, potong sayuran seperti tomat, selada, dan timun tipis-tipis.
     - Potong daging dan keju sesuai keinginan.
  
  3. **Panggang Roti (Opsional):**
     - Jika suka, panggang roti sebentar untuk memberikan rasa yang lebih gurih dan tekstur yang renyah. Pastikan tidak terlalu lama.
  
  4. **Olesi Roti dengan Mentega atau Margarin:**
     - Ambil selembar roti dan olesi permukaannya dengan mentega atau margarin menggunakan spatula atau sendok.
  
  5. **Susun Isi di Atas Roti:**
     - Letakkan potongan daging, keju, dan sayuran di atas roti yang telah diolesi mentega.
  
  6. **Tutup dengan Roti Lainnya:**
     - Tempatkan selembar roti lain di atas isi, sehingga membentuk sandwich.
  
  7. **Potong Sesuai Selera:**
     - Potong sandwich sesuai selera, bisa memotong menjadi dua bagian atau lebih.
  
  8. **Sajikan:**
     - Roti sandwich siap disajikan. Nikmati roti sandwich yang lezat dan sehat!
  
  **Tips:**
  - Eksperimen dengan berbagai kombinasi isi sesuai selera pribadi.
  - Jika suka, tambahkan saus atau dressing untuk memberikan cita rasa tambahan.
  
  Selamat mencoba membuat roti sandwich! Semoga berhasil.`)
}
handler.help = ['ai', 'openai']
handler.tags = ['info', 'fun']
handler.command = /^(ai|openai|ro)$/i
handler.premium = true
export default handler
